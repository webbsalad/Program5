from setuptools import setup

setup(name='open-weather_API',
      version='0.0',
      description='Openweather API',
      packages=['open-weather_API'],
      author_email='gnevnov1996@mail.ru',
      zip_safe=False)