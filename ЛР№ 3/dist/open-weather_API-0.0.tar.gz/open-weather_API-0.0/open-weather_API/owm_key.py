owm_api_key = '575a2f91669ced7f9ed448a82fd77dd7'
